subor = open('osoby.txt', 'r', encoding="utf-8")
osoby = []
roknarodenia = 0
vek = 2000
for riadok in subor:
    info = riadok.split(';')
    osoba = {}
    osoba['meno'] = info[0]
    osoba['vyska'] = int(info[1])
    osoba['roknarodenia'] = int(info[2])
    osoba['rodisko'] = info[3].strip()
    
    osoby.append(osoba)
    if 2022 - int(info[2]) < vek:
        vek = 2022-int(info[2])
        print(vek)
        
subor.close()
print(osoby)
