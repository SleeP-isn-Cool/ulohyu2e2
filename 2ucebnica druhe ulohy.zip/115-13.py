subor = open('osoby.txt', 'r', encoding="utf-8")
osoby = []
roknarodenia = 0
mesto = 0
for riadok in subor:
    info = riadok.split(';')
    osoba = {}
    osoba['meno'] = info[0]
    osoba['vyska'] = int(info[1])
    osoba['roknarodenia'] = int(info[2])
    osoba['rodisko'] = info[3].strip()
    if int(info[2]) == int(info[2]):
        print("roknarodenia: ",+ int(info[2]))
        roknarodenia = roknarodenia + 1
        print(roknarodenia)

    if str(info[3]) == str(info[3]):
        print("mesto: ")
        mesto = mesto + 1
        print(mesto)
    osoby.append(osoba)
subor.close()
print(osoby)
